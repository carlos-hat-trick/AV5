# AV5 — Classe Casa

Projeto baseado no exemplo fornecido, mantendo a classe `Pessoa` e o login padrão. A nova classe `Casa` tem oito atributos: endereço, cidade, estado, CEP, tipo, quartos, área em m² e valor.

## Pré-requisitos
- Git
- Python 3.12 ou superior
- Node.js LTS e npm
- `uv` para gerenciar o backend Python (instalação: https://docs.astral.sh/uv/)

## 1. Backend (terminal 1)
No Windows, abra PowerShell ou Terminal e execute:

```powershell
cd back-python
uv sync
uv run flask --app src/app run --debug
```

Deixe o terminal aberto. Na primeira execução, abra `http://127.0.0.1:5000/criar_banco` no navegador uma vez para criar as tabelas e o usuário padrão. A operação não duplica o usuário admin. O backend fica em `http://127.0.0.1:5000`.

Login: `admin` / Senha: `admin123`.

## 2. Frontend (terminal 2)
Na raiz do projeto, abra outro terminal:

```powershell
cd front-react-next
Copy-Item .env.local.example .env.local
npm ci
npm run dev
```

Abra `http://localhost:3000`. Se usar Prompt de Comando (cmd) em vez do PowerShell, copie `.env.local.example` para `.env.local` usando `copy .env.local.example .env.local`.

## 3. Testar a aplicação
1. Acesse `http://localhost:3000/form_login`.
2. Entre com `admin` e `admin123`.
3. Abra `http://localhost:3000/form_incluir_casa` e cadastre uma casa.
4. Abra `http://localhost:3000/listar_casas` para conferir o registro.
5. Sem login, tente cadastrar uma casa: a tela redireciona para login e a API exige token JWT. A listagem é pública.

## 4. Prints para a entrega
Com a janela do navegador maximizada, faça capturas de tela reais e salve em `prints/`:
- `01-home.png`: página inicial.
- `02-login.png`: login preenchido ou após entrar.
- `03-cadastro-casa.png`: formulário preenchido e mensagem de sucesso.
- `04-listagem-casas.png`: lista mostrando a casa cadastrada.

No Windows use `Win + Shift + S` e salve as capturas na pasta `prints` dentro da raiz do repositório. Não use imagens simuladas; capture a execução local.

## 5. Git — enviar para o repositório
Se o projeto já estiver clonado e o `origin` apontar para o repositório correto:

```powershell
git status
git add .
git commit -m "Implementa cadastro de casas para AV5"
git push origin main
```

Se a branch principal tiver outro nome, confira com `git branch --show-current` e use esse nome no push. Se ainda não clonou, use a URL do seu repositório: `git clone URL_DO_SEU_REPOSITORIO`, depois entre na pasta criada com `cd NOME_DA_PASTA`. Não envie para um repositório sem confirmar que é o seu.

## 6. Folha escrita — comandos para baixar e executar
**Baixar:**
```bash
git clone URL_DO_SEU_REPOSITORIO
cd NOME_DA_PASTA
```
**Executar backend:**
```bash
cd back-python
uv sync
uv run flask --app src/app run --debug
```
**Executar frontend (em outro terminal, a partir da raiz):**
```bash
cd front-react-next
# criar .env.local copiando .env.local.example
npm ci
npm run dev
```
Depois acessar `http://localhost:3000` no navegador.
