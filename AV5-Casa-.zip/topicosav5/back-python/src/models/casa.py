from config import *


class Casa(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    endereco = db.Column(db.String(250), nullable=False)
    cidade = db.Column(db.String(120), nullable=False)
    estado = db.Column(db.String(2), nullable=False)
    cep = db.Column(db.String(10), nullable=False)
    tipo = db.Column(db.String(60), nullable=False)
    quartos = db.Column(db.Integer, nullable=False)
    area_m2 = db.Column(db.Float, nullable=False)
    valor = db.Column(db.Float, nullable=False)

    def json(self):
        return {
            "id": self.id, "endereco": self.endereco, "cidade": self.cidade,
            "estado": self.estado, "cep": self.cep, "tipo": self.tipo,
            "quartos": self.quartos, "area_m2": self.area_m2, "valor": self.valor
        }
