from config import app, jsonify, request, jwt_required
import services.casa as casa_service


@app.route('/casas', methods=['GET'])
def listar_casas():
    casas = casa_service.retornar_casas()
    return jsonify({"resultado": "ok", "detalhes": [casa.json() for casa in casas]})


@app.route('/casa', methods=['POST'])
@jwt_required()
def incluir_casa():
    dados = request.get_json(silent=True) or {}
    obrigatorios = ["endereco", "cidade", "estado", "cep", "tipo", "quartos", "area_m2", "valor"]
    if any(dados.get(campo) in (None, "") for campo in obrigatorios):
        return jsonify({"resultado": "erro", "detalhes": "Preencha todos os campos da casa."}), 400
    try:
        if int(dados["quartos"]) < 0 or float(dados["area_m2"]) <= 0 or float(dados["valor"]) < 0:
            raise ValueError()
        casa = casa_service.criar_casa(dados)
    except (ValueError, TypeError):
        return jsonify({"resultado": "erro", "detalhes": "Quartos, área e valor devem ser números válidos."}), 400
    return jsonify({"resultado": "ok", "detalhes": casa.json()}), 201
