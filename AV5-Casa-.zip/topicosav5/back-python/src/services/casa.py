from config import db
from models.casa import Casa


def criar_casa(data):
    casa = Casa(
        endereco=data["endereco"].strip(), cidade=data["cidade"].strip(),
        estado=data["estado"].strip().upper(), cep=data["cep"].strip(),
        tipo=data["tipo"].strip(), quartos=int(data["quartos"]),
        area_m2=float(data["area_m2"]), valor=float(data["valor"])
    )
    db.session.add(casa)
    db.session.commit()
    return casa


def retornar_casas():
    return Casa.query.order_by(Casa.id.desc()).all()
