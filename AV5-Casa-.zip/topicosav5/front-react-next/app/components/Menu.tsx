import Link from "next/link";

export default function Menu() {
  return <nav className="bg-emerald-900 px-5 py-4 text-white shadow">
    <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-3">
      <Link href="/" className="mr-auto text-lg font-bold">Casa & Lar</Link>
      <Link href="/listar_casas" className="hover:text-emerald-200">Listar casas</Link>
      <Link href="/form_incluir_casa" className="hover:text-emerald-200">Cadastrar casa</Link>
      <Link href="/form_login" className="rounded-lg bg-white/10 px-3 py-2 hover:bg-white/20">Login</Link>
    </div>
  </nav>;
}
