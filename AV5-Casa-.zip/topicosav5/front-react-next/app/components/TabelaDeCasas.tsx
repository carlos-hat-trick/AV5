'use client';

import { useEffect, useState } from 'react';

type Casa = { id: number; endereco: string; cidade: string; estado: string; cep: string; tipo: string; quartos: number; area_m2: number; valor: number };
export default function TabelaDeCasas() {
  const [casas, setCasas] = useState<Casa[]>([]);
  const [mensagem, setMensagem] = useState('Carregando casas...');
  useEffect(() => {
    const api = process.env.NEXT_PUBLIC_API_URL;
    if (!api) { setMensagem('Configure NEXT_PUBLIC_API_URL no arquivo .env.local.'); return; }
    fetch(`${api}/casas`).then(async r => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.detalhes || 'Erro ao buscar casas');
      setCasas(Array.isArray(data.detalhes) ? data.detalhes : []);
      setMensagem(data.detalhes?.length ? '' : 'Nenhuma casa cadastrada ainda.');
    }).catch(() => setMensagem('Não foi possível carregar as casas. Verifique se o backend está ligado.'));
  }, []);
  const moeda = (valor: number) => valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  return <div className="w-full">
    {mensagem && <p className="rounded-lg bg-slate-100 p-4 text-slate-700">{mensagem}</p>}
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">{casas.map(c => <article key={c.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-3 flex items-start justify-between gap-3"><span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-900">{c.tipo}</span><span className="text-xs text-slate-500">Imóvel #{c.id}</span></div>
      <h2 className="text-lg font-bold text-slate-900">{c.endereco}</h2><p className="text-slate-600">{c.cidade} - {c.estado} · CEP {c.cep}</p>
      <div className="my-4 grid grid-cols-2 gap-3 text-sm"><p className="rounded-lg bg-slate-50 p-3">🛏️ {c.quartos} quarto(s)</p><p className="rounded-lg bg-slate-50 p-3">📐 {c.area_m2} m²</p></div>
      <p className="text-xl font-bold text-emerald-800">{moeda(c.valor)}</p>
    </article>)}</div>
    <a href="/form_incluir_casa" className="mt-6 inline-block rounded-lg bg-emerald-700 px-5 py-3 font-semibold text-white">Cadastrar outra casa</a>
  </div>;
}
