'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';

export default function FormIncluirCasa() {
  const router = useRouter();
  const [mensagem, setMensagem] = useState('');
  const [carregando, setCarregando] = useState(false);

  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) { router.replace('/form_login'); return; }
    const formulario = e.currentTarget;
    const form = new FormData(formulario);
    const api = process.env.NEXT_PUBLIC_API_URL;
    if (!api) { setMensagem('Configure NEXT_PUBLIC_API_URL no arquivo .env.local.'); return; }
    setCarregando(true); setMensagem('');
    try {
      const resposta = await fetch(`${api}/casa`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          endereco: form.get('endereco'), cidade: form.get('cidade'), estado: form.get('estado'),
          cep: form.get('cep'), tipo: form.get('tipo'), quartos: Number(form.get('quartos')),
          area_m2: Number(form.get('area_m2')), valor: Number(form.get('valor'))
        })
      });
      const dados = await resposta.json();
      if (!resposta.ok) { setMensagem(dados.detalhes || `Erro ${resposta.status}`); return; }
      setMensagem('Casa cadastrada com sucesso!');
      formulario.reset();
    } catch { setMensagem('Não foi possível conectar ao backend.'); }
    finally { setCarregando(false); }
  }

  const campos = [
    { name: 'endereco', label: 'Endereço', type: 'text' },
    { name: 'cidade', label: 'Cidade', type: 'text' },
    { name: 'estado', label: 'Estado (UF)', type: 'text' },
    { name: 'cep', label: 'CEP', type: 'text' },
    { name: 'tipo', label: 'Tipo (casa, sobrado etc.)', type: 'text' },
    { name: 'quartos', label: 'Quantidade de quartos', type: 'number' },
    { name: 'area_m2', label: 'Área em m²', type: 'number' },
    { name: 'valor', label: 'Valor em reais (R$)', type: 'number' },
  ];

  return <main className="mx-auto w-full max-w-2xl p-6 md:p-10">
    <h1 className="mb-2 text-3xl font-bold text-slate-900">Cadastrar casa</h1>
    <p className="mb-6 text-slate-600">Preencha os dados do imóvel. É necessário fazer login.</p>
    <form onSubmit={enviar} className="grid grid-cols-1 gap-4 rounded-2xl border bg-white p-6 shadow-sm md:grid-cols-2">
      {campos.map(c => <label key={c.name} className="flex flex-col gap-1 text-sm font-medium text-slate-700">{c.label}<input name={c.name} type={c.type} required min={c.type === 'number' ? 0 : undefined} step={c.name === 'area_m2' || c.name === 'valor' ? '0.01' : undefined} maxLength={c.type === 'text' ? 250 : undefined} className="rounded-lg border border-slate-300 p-3 outline-none focus:border-emerald-600" /></label>)}
      <button disabled={carregando} className="rounded-lg bg-emerald-700 p-3 font-semibold text-white hover:bg-emerald-800 disabled:opacity-60 md:col-span-2">{carregando ? 'Cadastrando...' : 'Cadastrar casa'}</button>
    </form>
    {mensagem && <p role="status" className="mt-4 rounded-lg bg-emerald-50 p-3 text-emerald-900">{mensagem}</p>}
    <p className="mt-5 text-sm text-slate-600">Quer conferir os imóveis? <a className="text-emerald-800 underline" href="/listar_casas">Ver casas cadastradas</a></p>
  </main>;
}
