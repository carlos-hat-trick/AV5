import TabelaDeCasas from '../components/TabelaDeCasas';

export default function ListarCasas() {
  return <main className="mx-auto w-full max-w-5xl flex-1 bg-slate-50 px-5 py-10 md:px-10">
    <h1 className="mb-2 text-3xl font-bold text-slate-900">Casas cadastradas</h1>
    <p className="mb-7 text-slate-600">Consulte os imóveis registrados no sistema.</p>
    <TabelaDeCasas />
  </main>;
}
