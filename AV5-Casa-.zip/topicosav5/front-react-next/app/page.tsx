import Link from 'next/link';

export default function Home() {
  return <main className="flex flex-1 items-center bg-gradient-to-br from-emerald-50 via-white to-amber-50 px-6 py-16">
    <section className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-2">
      <div><p className="mb-4 font-semibold uppercase tracking-[0.2em] text-emerald-800">Casa & Lar · Gestão imobiliária</p>
        <h1 className="text-4xl font-bold leading-tight text-slate-900 md:text-6xl">Encontre seu próximo <span className="text-emerald-800">lar.</span></h1>
        <p className="mt-5 max-w-xl text-lg leading-8 text-slate-600">Um sistema simples para cadastrar e consultar imóveis, reunindo endereço, características e valor em um só lugar.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/listar_casas" className="rounded-lg bg-emerald-800 px-5 py-3 font-semibold text-white hover:bg-emerald-900">Ver casas</Link><Link href="/form_login" className="rounded-lg border border-emerald-800 px-5 py-3 font-semibold text-emerald-900 hover:bg-emerald-50">Entrar para cadastrar</Link></div>
      </div>
      <div className="rounded-3xl bg-emerald-900 p-8 text-white shadow-xl"><div className="mb-5 text-6xl">⌂</div><h2 className="text-2xl font-bold">Seu imóvel, organizado.</h2><p className="mt-3 leading-7 text-emerald-100">Cadastre casas, consulte informações e mantenha os dados dos imóveis acessíveis pela aplicação.</p><div className="mt-8 grid grid-cols-2 gap-3"><div className="rounded-xl bg-white/10 p-4"><p className="text-sm text-emerald-100">Cadastro</p><p className="mt-1 font-semibold">Protegido por login</p></div><div className="rounded-xl bg-white/10 p-4"><p className="text-sm text-emerald-100">Informações</p><p className="mt-1 font-semibold">8 atributos</p></div></div></div>
    </section>
  </main>;
}
